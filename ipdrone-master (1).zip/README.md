## ABOUT TOOL :

Ipdrone is a simply python script, which can be used to Ip lookup and to get information of perticualr target Ip. This tool works on both rooted Android device and Non-rooted Android device.

<p align="center"><a href="https://rebrand.ly/noobhacktube"><img title="Noob Hackers" src="https://user-images.githubusercontent.com/49580304/117566254-31801e00-b0d3-11eb-860d-5601b1adccb8.jpg"></a>
</p>

## AVAILABLE ON :

* Termux

### TESTED ON :

* Termux

### REQUIREMENTS :
* internet
* storage 400 MB
* python

## FEATURES :
* [+] Real live location !
* [+] Updated maintainence !
* [+] Ip lookup
* [+] Easy for Beginners !

## INSTALLATION [Termux] :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install python -y`
* `pkg install python2 -y`
* `pkg install git -y`
* `pip install lolcat`
* `pip install requests`
* `git clone https://github.com/noob-hackers/ipdrone`
* `cd $HOME`
* `ls`
* `cd ipdrone`
* `ls`
* `python ipdrone.py -v (your victim ip here)`
```
ex:- python ipdrone.py -v 127.0,0.1

Hurray... you got his location with some more information

```

## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
